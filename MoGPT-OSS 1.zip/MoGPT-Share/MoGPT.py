import streamlit as st
from openai import OpenAI
from dotenv import load_dotenv
import os
import base64
from pathlib import Path
import mimetypes

# Load environment variables from .env file
load_dotenv()

# --- Page Configuration ---
st.set_page_config(
    page_title="LLM Proxy Comparison",
    page_icon="🤖",
    layout="wide"
)

# --- Helper Functions for File Processing ---
def encode_image(image_path):
    """Encode image to base64"""
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

def process_uploaded_file(uploaded_file):
    """Process uploaded file and return appropriate format for LLM"""
    file_type = uploaded_file.type
    file_name = uploaded_file.name
    
    # Save file temporarily
    temp_path = f"/tmp/{file_name}"
    with open(temp_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    # Image files
    if file_type.startswith('image/'):
        base64_image = encode_image(temp_path)
        return {
            'type': 'image',
            'data': base64_image,
            'mime_type': file_type,
            'name': file_name
        }
    
    # Text files
    elif file_type.startswith('text/') or file_name.endswith(('.txt', '.md', '.py', '.js', '.json', '.csv')):
        with open(temp_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        return {
            'type': 'text',
            'data': content,
            'name': file_name
        }
    
    # PDF files
    elif file_type == 'application/pdf':
        try:
            import PyPDF2
            with open(temp_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                text = ""
                for page in pdf_reader.pages:
                    text += page.extract_text()
            return {
                'type': 'text',
                'data': text,
                'name': file_name
            }
        except ImportError:
            return {
                'type': 'error',
                'data': 'PDF support requires PyPDF2. Install it with: pip install PyPDF2',
                'name': file_name
            }
    
    else:
        return {
            'type': 'unsupported',
            'data': f'File type {file_type} is not supported yet.',
            'name': file_name
        }

def format_message_with_file(text, file_info):
    """Format message content with file for OpenAI API"""
    if file_info['type'] == 'image':
        return [
            {
                "type": "text",
                "text": text
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:{file_info['mime_type']};base64,{file_info['data']}"
                }
            }
        ]
    elif file_info['type'] == 'text':
        return f"{text}\n\n[File: {file_info['name']}]\n```\n{file_info['data'][:2000]}{'...' if len(file_info['data']) > 2000 else ''}\n```"
    else:
        return text

# --- Client Configuration ---
@st.cache_resource
def initialize_clients():
    """Initialize both OpenAI clients (direct and via Quilr proxy)"""
    clients = {}
    errors = {}
    
    # Get API keys from environment variables
    openai_api_key = os.getenv("OPENAI_API_KEY")
    quilr_api_key = os.getenv("QUILR_API_KEY")
    quilr_base_url = os.getenv("QUILR_BASE_URL", "https://guardrails.quilr.ai/openai_compatible/")
    
    # Direct OpenAI Client
    if openai_api_key:
        try:
            clients['direct'] = OpenAI(
                api_key=openai_api_key,
                max_retries=2
            )
        except Exception as e:
            errors['direct'] = f"Direct OpenAI client failed: {e}"
    else:
        errors['direct'] = "No OpenAI API key found in .env file. Add OPENAI_API_KEY to enable direct comparison."
    
    # Quilr Proxy Client
    if quilr_api_key:
        try:
            clients['quilr'] = OpenAI(
                base_url=quilr_base_url,
                api_key=quilr_api_key,
                max_retries=2
            )
        except Exception as e:
            errors['quilr'] = f"Quilr proxy client failed: {e}"
    else:
        errors['quilr'] = "No Quilr API key found in .env file. Add QUILR_API_KEY to enable Quilr proxy."
    
    return clients, errors

clients, init_errors = initialize_clients()

# --- Sidebar Configuration ---
st.sidebar.title("⚙️ Configuration")

# Display client status
with st.sidebar.expander("🔌 Client Status", expanded=True):
    if 'direct' in clients:
        st.success("✅ Direct OpenAI: Connected")
    else:
        st.warning("⚠️ Direct OpenAI: Not configured")
    
    if 'quilr' in clients:
        st.success("✅ Quilr Proxy: Connected")
    else:
        st.warning("⚠️ Quilr Proxy: Not configured")

# Show detailed errors if any
if init_errors and any("failed" in error.lower() for error in init_errors.values()):
    with st.sidebar.expander("⚠️ Connection Errors", expanded=False):
        for client_name, error in init_errors.items():
            if "failed" in error.lower():
                st.error(f"**{client_name.title()}**: {error}")

# Model selection
model = st.sidebar.selectbox(
    "Select Model",
    ["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo", "gpt-4-turbo","gpt-5-nano"],
    index=0,
    help="Choose the OpenAI model to use"
)

# Mode selection - disable options based on available clients
available_modes = []
if 'direct' in clients and 'quilr' in clients:
    available_modes = ["Side-by-Side Comparison", "Direct OpenAI Only", "Quilr Proxy Only"]
    default_index = 0
elif 'direct' in clients:
    available_modes = ["Direct OpenAI Only"]
    default_index = 0
elif 'quilr' in clients:
    available_modes = ["Quilr Proxy Only"]
    default_index = 0
else:
    st.error("❌ No clients available. Please check your .env file configuration.")
    st.stop()

mode = st.sidebar.radio(
    "Comparison Mode",
    available_modes,
    index=default_index
)

# File Upload Section
st.sidebar.markdown("---")
st.sidebar.markdown("### 📎 File Upload")
uploaded_files = st.sidebar.file_uploader(
    "Upload files (images, text, PDF)",
    type=['png', 'jpg', 'jpeg', 'gif', 'webp', 'txt', 'md', 'py', 'js', 'json', 'csv', 'pdf'],
    accept_multiple_files=True,
    help="Upload images for vision models or documents for text analysis"
)

# Process uploaded files
if uploaded_files:
    st.sidebar.markdown(f"**{len(uploaded_files)} file(s) uploaded:**")
    for file in uploaded_files:
        st.sidebar.text(f"📄 {file.name}")

# Temperature slider
st.sidebar.markdown("---")
temperature = st.sidebar.slider(
    "Temperature",
    min_value=0.0,
    max_value=2.0,
    value=0.7,
    step=0.1,
    help="Higher values make output more random, lower values more deterministic"
)

# Max tokens slider
max_tokens = st.sidebar.slider(
    "Max Tokens",
    min_value=100,
    max_value=4000,
    value=1000,
    step=100,
    help="Maximum number of tokens in the response"
)

# Clear chat button
if st.sidebar.button("🗑️ Clear Chat History"):
    st.session_state.messages_direct = []
    st.session_state.messages_quilr = []
    if 'processed_files' in st.session_state:
        del st.session_state.processed_files
    st.rerun()

# Display mode information
st.sidebar.markdown("---")
st.sidebar.markdown("### 📊 Current Mode")
if mode == "Direct OpenAI Only":
    st.sidebar.info("🔵 Calling OpenAI API directly without guardrails")
elif mode == "Quilr Proxy Only":
    st.sidebar.info("🟢 Calling through Quilr guardrails proxy")
else:
    st.sidebar.info("🔵🟢 Comparing both direct and proxied responses")

# --- Main App ---
st.title("🤖 LLM Proxy Comparison Tool")
st.markdown("*Compare responses with and without guardrails*")

# Initialize separate chat histories for each mode
if "messages_direct" not in st.session_state:
    st.session_state.messages_direct = []

if "messages_quilr" not in st.session_state:
    st.session_state.messages_quilr = []

if "processed_files" not in st.session_state:
    st.session_state.processed_files = []

# Process uploaded files once
if uploaded_files and len(uploaded_files) != len(st.session_state.processed_files):
    st.session_state.processed_files = []
    for uploaded_file in uploaded_files:
        file_info = process_uploaded_file(uploaded_file)
        st.session_state.processed_files.append(file_info)

# --- Helper Function ---
def get_llm_response(client, messages, model_name, temperature, max_tokens, stream=True):
    """Get response from LLM (works for both direct and proxy)"""
    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream
        )
        return response, None
    except Exception as e:
        return None, str(e)

# --- Display Chat History ---
def display_chat_history(messages, title=None):
    """Display chat messages"""
    if title:
        st.markdown(f"**{title}**")
    
    if not messages:
        st.info("No messages yet. Start a conversation below!")
        return
    
    for message in messages:
        with st.chat_message(message["role"]):
            # Handle both string and list content (for images)
            if isinstance(message["content"], list):
                for item in message["content"]:
                    if item["type"] == "text":
                        st.markdown(item["text"])
                    elif item["type"] == "image_url":
                        st.image(item["image_url"]["url"])
            else:
                st.markdown(message["content"])

# Display existing messages based on mode
if mode == "Side-by-Side Comparison":
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🔵 Direct OpenAI")
        display_chat_history(st.session_state.messages_direct)
    
    with col2:
        st.markdown("### 🟢 Quilr Proxy (with Guardrails)")
        display_chat_history(st.session_state.messages_quilr)
else:
    messages = st.session_state.messages_direct if mode == "Direct OpenAI Only" else st.session_state.messages_quilr
    display_chat_history(messages)

# --- Chat Input ---
if prompt := st.chat_input("Type your message here..."):
    
    # Prepare message content with files
    message_content = prompt
    if st.session_state.processed_files:
        for file_info in st.session_state.processed_files:
            if file_info['type'] == 'image':
                # For images, create multimodal content
                message_content = format_message_with_file(prompt, file_info)
                break  # Use first image for now
            elif file_info['type'] == 'text':
                # For text files, append content
                message_content = format_message_with_file(prompt, file_info)
    
    # Side-by-Side Comparison Mode
    if mode == "Side-by-Side Comparison":
        col1, col2 = st.columns(2)
        
        # Add user message to both histories
        st.session_state.messages_direct.append({"role": "user", "content": message_content})
        st.session_state.messages_quilr.append({"role": "user", "content": message_content})
        
        # Display user message in both columns
        with col1:
            st.markdown("### 🔵 Direct OpenAI")
            with st.chat_message("user"):
                st.markdown(prompt)
                # Display uploaded files
                if st.session_state.processed_files:
                    for file_info in st.session_state.processed_files:
                        if file_info['type'] == 'image':
                            st.image(f"data:{file_info['mime_type']};base64,{file_info['data']}", 
                                   caption=file_info['name'], width=300)
                        elif file_info['type'] == 'text':
                            with st.expander(f"📄 {file_info['name']}"):
                                st.text(file_info['data'][:500] + "..." if len(file_info['data']) > 500 else file_info['data'])
        
        with col2:
            st.markdown("### 🟢 Quilr Proxy (with Guardrails)")
            with st.chat_message("user"):
                st.markdown(prompt)
                # Display uploaded files
                if st.session_state.processed_files:
                    for file_info in st.session_state.processed_files:
                        if file_info['type'] == 'image':
                            st.image(f"data:{file_info['mime_type']};base64,{file_info['data']}", 
                                   caption=file_info['name'], width=300)
                        elif file_info['type'] == 'text':
                            with st.expander(f"📄 {file_info['name']}"):
                                st.text(file_info['data'][:500] + "..." if len(file_info['data']) > 500 else file_info['data'])
        
        # Get responses from both
        # Column 1: Direct OpenAI
        with col1:
            with st.chat_message("assistant"):
                if 'direct' not in clients:
                    st.error("Direct OpenAI client not available")
                    st.session_state.messages_direct.pop()
                else:
                    message_placeholder = st.empty()
                    full_response = ""
                    
                    stream, error = get_llm_response(
                        clients['direct'],
                        st.session_state.messages_direct,
                        model,
                        temperature,
                        max_tokens
                    )
                    
                    if error:
                        st.error(f"Error: {error}")
                        st.session_state.messages_direct.pop()
                    else:
                        for chunk in stream:
                            if chunk.choices[0].delta.content is not None:
                                full_response += chunk.choices[0].delta.content
                                message_placeholder.markdown(full_response + "▌")
                        
                        message_placeholder.markdown(full_response)
                        st.session_state.messages_direct.append({
                            "role": "assistant",
                            "content": full_response
                        })
        
        # Column 2: Quilr Proxy
        with col2:
            with st.chat_message("assistant"):
                if 'quilr' not in clients:
                    st.error("Quilr proxy client not available")
                    st.session_state.messages_quilr.pop()
                else:
                    message_placeholder = st.empty()
                    full_response = ""
                    
                    stream, error = get_llm_response(
                        clients['quilr'],
                        st.session_state.messages_quilr,
                        model,
                        temperature,
                        max_tokens
                    )
                    
                    if error:
                        st.error(f"Error: {error}")
                        st.session_state.messages_quilr.pop()
                    else:
                        for chunk in stream:
                            if chunk.choices[0].delta.content is not None:
                                full_response += chunk.choices[0].delta.content
                                message_placeholder.markdown(full_response + "▌")
                        
                        message_placeholder.markdown(full_response)
                        st.session_state.messages_quilr.append({
                            "role": "assistant",
                            "content": full_response
                        })
    
    # Single Mode (Direct or Quilr only)
    else:
        # Determine which client and messages to use
        if mode == "Direct OpenAI Only":
            client_key = 'direct'
            messages_list = st.session_state.messages_direct
        else:
            client_key = 'quilr'
            messages_list = st.session_state.messages_quilr
        
        # Add user message
        messages_list.append({"role": "user", "content": message_content})
        
        # Display user message
        with st.chat_message("user"):
            st.markdown(prompt)
            # Display uploaded files
            if st.session_state.processed_files:
                for file_info in st.session_state.processed_files:
                    if file_info['type'] == 'image':
                        st.image(f"data:{file_info['mime_type']};base64,{file_info['data']}", 
                               caption=file_info['name'], width=300)
                    elif file_info['type'] == 'text':
                        with st.expander(f"📄 {file_info['name']}"):
                            st.text(file_info['data'][:500] + "..." if len(file_info['data']) > 500 else file_info['data'])
        
        # Get and display assistant response
        with st.chat_message("assistant"):
            if client_key not in clients:
                st.error(f"{client_key.title()} client not available")
                messages_list.pop()
            else:
                message_placeholder = st.empty()
                full_response = ""
                
                stream, error = get_llm_response(
                    clients[client_key],
                    messages_list,
                    model,
                    temperature,
                    max_tokens
                )
                
                if error:
                    st.error(f"Error: {error}")
                    messages_list.pop()
                else:
                    for chunk in stream:
                        if chunk.choices[0].delta.content is not None:
                            full_response += chunk.choices[0].delta.content
                            message_placeholder.markdown(full_response + "▌")
                    
                    message_placeholder.markdown(full_response)
                    messages_list.append({
                        "role": "assistant",
                        "content": full_response
                    })

# --- Footer ---
st.sidebar.markdown("---")
st.sidebar.markdown("### 📝 About")
st.sidebar.markdown("""
This app demonstrates:
- **Direct OpenAI**: Standard API calls
- **Quilr Proxy**: Calls with guardrails
- **Side-by-Side**: Compare both approaches

**File Upload Support:**
- 🖼️ Images (PNG, JPG, GIF, WebP)
- 📄 Text files (TXT, MD, PY, JS, JSON, CSV)
- 📕 PDF documents

**Configuration:**
Edit the `.env` file to add your API keys.
""")